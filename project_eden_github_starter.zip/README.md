# PROJECT EDEN:e — GitHub Pages starter

## ファイル
- `index.html`：HOMEページの内容
- `style.css`：色・レイアウト・スマホ/PC表示
- `images/`：画像を入れるフォルダ（あとから差し替え）

## GitHub Pagesで公開する手順
1. GitHubで新しいリポジトリを作成する（例：`project-eden-e`）。
2. `index.html` と `style.css`、`images` フォルダをアップロードする。
3. リポジトリの **Settings → Pages** を開く。
4. **Deploy from a branch** を選び、`main` と `/ (root)` を指定して保存する。
5. 表示された公開URLを開く。

## 画像の差し替え
現在は位置がわかる仮画像になっています。画像を `images` フォルダへアップロードし、HTMLの該当箇所を例えば次のように変更します。

```html
<div class="hero-art image-placeholder">
  <img src="images/main-visual.jpg" alt="PROJECT EDEN:e メインビジュアル">
</div>
```

画像表示用CSSは必要に応じて追加します。実際の画像ファイル名に合わせて `src` を変更してください。

※これはスクリーンショットをもとにした再現用の土台です。画像・本文・実際のJimdo上の細部は、素材を見ながら後から調整します。
