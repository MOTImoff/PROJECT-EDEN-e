PROJECT EDEN:e — website starter files
=======================================

このフォルダは、スマホ表示に対応した静的ホームページのたたき台です。

ファイル
- index.html : ページの内容
- styles.css : 色・配置・装飾
- script.js  : キャラクター切り替えとスマホメニュー
- assets/    : 立ち絵やロゴ画像を入れる場所

まず確認すること
1. ZIPを展開して、index.html / styles.css / script.js が同じ階層にあることを確認します。
2. index.html をブラウザで開くと、仮デザインを確認できます。
3. 公開するときは、index.html / styles.css / script.js / assets フォルダの中身をまとめてアップロードします。

キャラクター画像を追加する
1. assets フォルダに画像を入れます（例: theseus.png）。
2. script.js 内の該当キャラクターの image: "" を image: "assets/theseus.png" に変更します。
3. ファイル名の大文字・小文字も完全に一致させます。

注意
- WORLDや未入力キャラクターの文章は仮テキストです。
- 外部フォントを読み込むため、ネット接続時にGoogle Fontsが利用可能ならフォントが反映されます。読み込めない場合も代替フォントで表示されます。
- これは静的サイトです。ログインやデータベースは使っていません。
