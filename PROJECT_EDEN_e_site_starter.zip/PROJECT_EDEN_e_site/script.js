const subjects = [
  {id:"N",number:"No.00",label:"PROTAGONIST",name:"N",english:"THE UNIDENTIFIED",age:"—",height:"—",affiliation:"EDEN:e",quote:"「主人公の台詞をここに入力してください。」",about:"人物紹介をここに入力してください。現在、この記録は未完成です。",keywords:["存在","記憶","未登録"],status:"PARTIAL",image:""},
  {id:"I",number:"No.01",label:"THESEUS",name:"テセウス",english:"THESEUS",age:"3■",height:"183 cm",affiliation:"UNIVERSE",quote:"「大切なもの、思い出のもの、全て私は大事にしますよ。」",about:"物腰が丁寧で非常に穏やかな男性。生き物を愛し、医師免許を持つ。知能が高く、縫合や解剖が得意。観葉植物を育てている。",keywords:["医師","融合","縫合"],status:"REGISTERED",image:""},
  {id:"II",number:"No.02",label:"MARY",name:"メアリー",english:"MARY",age:"2■",height:"159 cm",affiliation:"UNIVERSE",quote:"「あたし、ちょっとは頭良いからさ！任せてよ！」",about:"元気で面倒見のよい女性。実は「世紀最大の天才」と呼ばれていたが、現在は科学に触れていない。子どもにとても優しい。",keywords:["科学者","天才","■■■■"],status:"REGISTERED",image:""},
  {id:"III",number:"No.03",label:"MILGRAM",name:"ミルグラム",english:"MILGRAM",age:"2■",height:"168 cm",affiliation:"UNIVERSE",quote:"「命令は絶対です。」",about:"命令に忠実で、正義感の強い女性。女性に対しては特に優しい。",keywords:["命令","正義","服従"],status:"PARTIAL",image:""},
  {id:"IV",number:"No.04",label:"ICARUS",name:"イカロス",english:"ICARUS",age:"28",height:"187 cm",affiliation:"UNIVERSE",quote:"「暗い顔すんなって。ほら、笑えよ。」",about:"明るく柔軟で、冗談をよく言う男性。重苦しい空気が苦手。髪に隠れた部分には、ひどい火傷の痕がある。",keywords:["天使","墜落","火傷"],status:"PARTIAL",image:""},
  {id:"V",number:"No.05",label:"BABEL",name:"バベル",english:"BABEL",age:"—",height:"165 cm",affiliation:"UNIVERSE",quote:"「キャラクターの台詞をここに入力してください。」",about:"ヴェールをまとった、謎めいた寡黙な女性。世界一の美貌を持つとされ、夜や月を好む。",keywords:["美貌","身元不明","月"],status:"PARTIAL",image:""},
  {id:"VI",number:"No.06",label:"ECHO CHAMBER",name:"Echo Chamber",english:"ECHO CHAMBER",age:"—",height:"—",affiliation:"UNIVERSE",quote:"「キャラクターの台詞をここに入力してください。」",about:"人物紹介をここに入力してください。",keywords:["社会","共鳴","未登録"],status:"UNREGISTERED",image:""},
  {id:"VII",number:"No.07",label:"STANFORD",name:"Stanford",english:"STANFORD",age:"—",height:"—",affiliation:"UNIVERSE",quote:"「キャラクターの台詞をここに入力してください。」",about:"人物紹介をここに入力してください。",keywords:["認知","傍観","未登録"],status:"UNREGISTERED",image:""},
  {id:"VIII",number:"No.08",label:"MEMENTO",name:"Memento",english:"MEMENTO",age:"—",height:"—",affiliation:"UNIVERSE",quote:"「キャラクターの台詞をここに入力してください。」",about:"人物紹介をここに入力してください。",keywords:["記憶","記録","未登録"],status:"UNREGISTERED",image:""}
];

const subjectNav = document.getElementById("subjectNav");
const field = id => document.getElementById(id);
function renderSubject(subject){
  field("subjectCurrent").textContent = subject.id;
  field("portraitNumber").textContent = subject.number;
  field("characterNumber").textContent = `SUBJECT ${subject.id} / ${subject.label}`;
  field("characterName").innerHTML = `${escapeHtml(subject.name)} <span>—</span>`;
  field("characterEnglish").textContent = subject.english;
  field("subjectStatus").textContent = subject.status;
  field("characterQuote").textContent = subject.quote;
  field("characterAbout").textContent = subject.about;
  field("characterIndex").textContent = `FILE ${String(subjects.indexOf(subject)).padStart(2,"0")} / 09`;
  field("profileLines").innerHTML = [
    ["AGE",subject.age],["HEIGHT",subject.height],["AFFILIATION",subject.affiliation]
  ].map(([label,value])=>`<div class="profile-item"><small>${label}</small><span>${escapeHtml(value)}</span></div>`).join("");
  field("characterKeywords").innerHTML = subject.keywords.map(k=>`<span class="keyword">${escapeHtml(k)}</span>`).join("");
  const placeholder = field("portraitPlaceholder");
  const existing = placeholder.querySelector("img");
  if(existing) existing.remove();
  const silhouette = placeholder.querySelector(".portrait-silhouette");
  const small = placeholder.querySelector("small");
  if(subject.image){
    const img = document.createElement("img");
    img.src = subject.image; img.alt = `${subject.name} portrait`;
    img.style.cssText = "width:100%;height:100%;object-fit:contain;position:absolute;inset:0;z-index:2";
    img.onerror = () => { img.remove(); silhouette.hidden = false; small.hidden = false; };
    placeholder.appendChild(img); silhouette.hidden = true; small.hidden = true;
  } else { silhouette.hidden = false; small.hidden = false; }
  subjectNav.querySelectorAll("button").forEach(button=>{
    const active = button.dataset.subject === subject.id;
    button.classList.toggle("active",active);
    button.setAttribute("aria-pressed",String(active));
  });
}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
subjects.forEach(subject=>{
  const button = document.createElement("button");
  button.className = "subject-button"; button.type = "button";
  button.textContent = subject.id; button.dataset.subject = subject.id;
  button.setAttribute("aria-label",`キャラクター ${subject.id} を表示`);
  button.addEventListener("click",()=>renderSubject(subject));
  subjectNav.appendChild(button);
});
renderSubject(subjects[0]);
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");
menuToggle.addEventListener("click",()=>{
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded",String(open));
  menuToggle.querySelector("span").textContent = open ? "－" : "＋";
});
mainNav.querySelectorAll("a").forEach(link=>link.addEventListener("click",()=>{
  mainNav.classList.remove("open"); menuToggle.setAttribute("aria-expanded","false");
  menuToggle.querySelector("span").textContent = "＋";
}));
